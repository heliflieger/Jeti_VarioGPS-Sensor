var searchData=
[
  ['varioms5611_20library_2c_20supporting_20barometric_20variometer_2c_20altimeter_2c_31',['VarioMS5611 library, supporting barometric variometer, altimeter,',['../index.html',1,'']]],
  ['varioms5611_32',['VarioMS5611',['../classVarioMS5611.html',1,'']]],
  ['varioms5611_2eh_33',['VarioMS5611.h',['../VarioMS5611_8h.html',1,'']]]
];
